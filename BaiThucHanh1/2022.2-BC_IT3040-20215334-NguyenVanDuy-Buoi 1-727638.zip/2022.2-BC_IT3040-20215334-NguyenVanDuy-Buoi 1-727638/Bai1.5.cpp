// Nguyen Van Duy - 20215334
/*
B�i 1.5. Vi?t h�m tr? v? con tr? tr? t?i
gi� tr? l?n nh?t c?a m?t m?ng c�c s? double.
N?u m?ng r?ng h�y tr? v? NULL.
*/
double* maximum(double* a, int size){
    double *max;
    max = a;
    if (a==NULL) return NULL;

    /*****************
    # YOUR CODE HERE #
    *****************/
    for (int i = 0; i < size; ++i) {
        if (*(a+i) > *max) {
            max = a+i;
        }
    }
    
    return max;
}
// Nguyen Van Duy - 20215334
