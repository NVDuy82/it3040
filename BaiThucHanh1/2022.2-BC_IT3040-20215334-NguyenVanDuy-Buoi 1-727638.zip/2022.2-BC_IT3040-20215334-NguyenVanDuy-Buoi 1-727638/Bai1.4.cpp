// Nguyen Van Duy - 20215334
/*
B�i 1.4. Vi?t h�m countEven(int*, int)
nh?n m?t m?ng s? nguy�n v� k�ch thu?c c?a m?ng,
tr? v? s? lu?ng s? ch?n trong m?ng???
*/
int counteven(int* arr, int size){
    int count = 0;
    
    /*****************
    # YOUR CODE HERE #
    *****************/
    for (int i = 0; i < size; ++i) {
        if (!(arr[i] & 1)) {
            ++count;
        }
    }
    
    return count;    
}
// Nguyen Van Duy - 20215334
