// Nguyen Van Duy - 20215334
/*
B�i 1.1. Vi?t m?t chuong tr�nh C nh?p v�o 3 s? nguy�n.
Thi?t l?p m?t con tr? d? l?n lu?t tr? t?i t?ng s? nguy�n
v� hi?n th? k?t qu? gi� tr? tham chi?u ngu?c c?a con tr?.
*/
# include <stdio.h>
int main(){
    int x, y, z;
    int* ptr;
    printf("Enter three integers: ");
    scanf("%d %d %d", &x, &y, &z);
    // Nhap 3 so nguyen x, y, z
    
    printf("\nThe three integers are:\n");
    ptr = &x; // Gan dia chi cua x cho ptr
    printf("x = %d\n", *ptr);
    
    /*****************
    # YOUR CODE HERE #
    *****************/
    ptr = &y; // Gan dia chi cua y cho ptr
    printf("y = %d\n", *ptr);
    ptr = &z; // Gan dia chi cua z cho ptr
    printf("z = %d\n", *ptr);
    
    
    return 0;
}
// Nguyen Van Duy - 20215334
