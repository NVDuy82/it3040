// Nguyen Van Duy - 20215334
/*
B�i 1.6. Vi?t h�m d?o ngu?c m?t m?ng
c�c s? nguy�n theo hai c�ch:
d�ng ch? s? v� d�ng con tr?.
*/
void reversearray(int arr[], int size){
    int l = 0, r = size - 1, tmp;
    
    /*****************
    # YOUR CODE HERE #
    *****************/
    while (l < r) {
        // swap
        tmp = arr[l];
        arr[l] = arr[r];
        arr[r] = tmp;
        ++l;
        --r;
    }
}

void ptr_reversearray(int *arr, int size){
    int l = 0, r = size - 1, tmp;
    
    /*****************
    # YOUR CODE HERE #
    *****************/
    while (l < r) {
        // swap
        tmp = *(arr+l);
        *(arr+l) = *(arr+r);
        *(arr+r) = tmp;
        ++l;
        --r;
    }
}

// Nguyen Van Duy - 20215334
