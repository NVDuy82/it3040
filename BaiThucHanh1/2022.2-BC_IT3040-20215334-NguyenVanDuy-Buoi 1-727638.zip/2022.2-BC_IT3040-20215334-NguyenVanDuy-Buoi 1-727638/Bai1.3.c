// Nguyen Van Duy - 20215334
/*
B�i 1.3. Vi?t chuong tr�nh y�u c?u nh?p gi� tr? cho
3 bi?n s? nguy�n x, y, z ki?u int.
Sau d� s? d?ng duy nh?t m?t con tr? d? c?ng gi� tr?
c?a m?i bi?n th�m 100.
*/
#include <stdio.h>
int main() {
    int x, y, z;
    int *ptr;
    scanf("%d %d %d", &x, &y, &z);
    // Nhap 3 so nguyen x, y, z
    printf("Here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);

    /*****************
    # YOUR CODE HERE #
    *****************/
    ptr = &x; // Gan dia chi cua x cho ptr
    *ptr += 100; // Cong them 100
    ptr = &y; // Gan dia chi cua y cho ptr
    *ptr += 100; // Cong them 100
    ptr = &z; // Gan dia chi cua z cho ptr
    *ptr += 100; // Cong them 100

    printf("Once again, here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);
    return 0;
}
// Nguyen Van Duy - 20215334
